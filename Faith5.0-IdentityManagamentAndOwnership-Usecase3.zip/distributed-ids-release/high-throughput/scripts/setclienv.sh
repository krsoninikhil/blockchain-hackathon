export CHANNEL_NAME=mychannel
export CC_NAME=bigdatacc
